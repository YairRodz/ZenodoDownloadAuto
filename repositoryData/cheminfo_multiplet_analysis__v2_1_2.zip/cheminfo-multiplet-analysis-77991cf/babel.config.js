module.exports = {
  "plugins": ["@babel/plugin-transform-modules-commonjs"]
};
